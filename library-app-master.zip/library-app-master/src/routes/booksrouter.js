var express = require('express');
var multer=require('multer');
var mongoose=require('mongoose')
var url="mongodb://127.0.0.1:27017/librarydb";
var booksmodel=require('../../model/books');
const booksRouter = express.Router();

mongoose.connect(url,function(err){
    if(err)throw err;
    else
    console.log("dtabase conection established")
});

var books = [
    {
        title: "STORIES FROM INDIA",
        genre:" STORY",
        author:"USBORNE",
        image:"1.jpg"
    },
    {
        title: "PAX INDICA",
        genre:"Fantasy fiction",
        author:"SHAHI THAROOR",
        image:"2.jpg"
    },
    {
        title: "ASURA",
        genre:"BIOGRAPHY",
        author:"ANAND NELAKANDAN",
        image:"3.jpg"
    },
    {
        title: "WHY I AM A HINDU",
        genre:"Crime thriller",
        author:"SHASHI THAROOR",
        image:"4.jpg"
    }
]

function router(nav){

    booksRouter.route('/')
    .get((req,res)=>{
        res.render("books.ejs",{nav,title:'Books',books});
    });

    booksRouter.route('/addbooks')
    .get((req,res)=>{
        res.render("addbooks.ejs",{nav,title:'Add a Book'})
    });

    booksRouter.route('/deletebooks')
    .get((req,res)=>{
        res.render("deletebooks.ejs",{nav,title:'Delete a Book'})
    });

    
    booksRouter.route('/updatebooks')
    .get((req,res)=>{
        res.render("updatebooks.ejs",{nav,title:'Update a Book'})
    });

    booksRouter.post('/save',function(req,res){
        var newbook= new booksmodel();
        newbook.title=req.body.title;
        newbook.author=req.body.author;
        newbook.genre=req.body.genre;
        newbook.save(function(err){
            if(err)throw err;
            else{
                res.send("book added")
            }
        })

    })


    booksRouter.post('/delete',function(req,res){
        booksmodel.deleteOne({title:req.body.title,author:req.body.author,genre:req.body.genre},function(err){
            if(err)throw err;
            else{
                res.send("book deleted")
            }
        })
    })
    

booksRouter.route('/:id')
    .get((req,res)=>{
        var i = req.params.id; 
        res.render("book.ejs",{nav,book:books[i]});
    })
return booksRouter;
}



module.exports = router;
