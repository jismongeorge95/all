var express = require('express');
const authorsRouter = express.Router();

var authors=[
    {
        name:'Shasshi Tharoor',
        age:52,
        about:'Shashi Tharoor (born 9 March 1956)[1] is an Indian politician, writer and a former career international diplomat[2] who is currently serving as Member of Parliament, Lok Sabha from Thiruvananthapuram, Kerala, since 2009. He also serves as Chairman of the Parliamentary Standing Committee on Information Technology[3] and All India Professionals Congress.[4] He formerly served as Chairman of the Parliamentary Standing Committee on External Affairs (2014 to 2019).[5',
        image:'author1.jpg'
    },
    {
        name:'kamla suraya',
        age:'75',
        about:'Kamala Surayya, popularly known by her one-time pen name Madhavikutty and married name Kamala Das, was an Indian English poet as well as a leading Malayalam author from Kerala, India. Wikipedia',
        image:'author2.jpg'
    },
    {
        name:'O.N.V KURIP',
        age:80,
        about:'Ottaplakkal Neelakandan Velu Kurup (27 May 1931 – 13 February 2016), popularly known as O. N. V. Kurup or simply and endearingly O. N. V., was a Malayalam poet and lyricist from Kerala, India, who won the Jnanpith Award, the highest literary award in India for the year 2007.',
        image:'author3.jpg'
    },
    {
        name:'A.P.J ABDUL KALAM',
        age:72,
        about:'Avul Pakir Jainulabdeen Abdul Kalam was an aerospace scientist who served as the 11th President of India from 2002 to 2007. He was born and raised in Rameswaram, Tamil Nadu and studied physics and aerospace engineering. Wikipedia',
        image:'author4.jpg'
    },
];
function router(nav){
    authorsRouter.route('/')
    .get((req,res)=>{
        res.render("authors.ejs",{nav,title:'Authors',authors});
    })

    authorsRouter.route('/:id')
    .get((req,res)=>{
        var i=req.params.id;
        res.render("author.ejs",{nav,author:authors[i]})
    })

    return authorsRouter;
}
module.exports= router;
