var express = require('express');

var mongoose=require('mongoose')
var empModel=require("../model/employe");
var url=("mongodb://127.0.0.1:27017/jismon");
var emprouter = express.Router();
mongoose.connect(url,function(err){
    if (err) throw err
    else
    {
        console.log("connection established")
    }
})

emprouter.route('/newemp')
.get((req,res)=>{
    res.render("newemp")
})
emprouter.route('/editemp')
.get((req,res)=>{
    res.render("editemp")
})
emprouter.route('/deleteemp')
.get((req,res)=>{
    res.render("deleteemp")
})

emprouter.post('/save',(req,res)=>{
    var newemp=new empModel();
    newemp.Name=req.body.Name;
    newemp.Eid=req.body.Eid;
    newemp.Salary=req.body.Salary;
    newemp.save(function(err){
        if(err) throw err
        else
        {
            res.send("data added")
        }
    })

})
emprouter.post("/delsubmit",function(req,res)
{
empModel.deleteOne({Eid:req.body.Eid},function(err){
    if(err)throw err
    else{
        res.send("DATA DELETED")
    }
})
})

module.exports = emprouter;