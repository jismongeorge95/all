var mongoose=require("mongoose")
var schema=mongoose.schema;
var empschema= new mongoose.Schema({
Name:String,
Eid:{type:String,require:true},
Salary:Number
})

var empModel=mongoose.model("employee",empschema,"emp");
module.exports=empModel;