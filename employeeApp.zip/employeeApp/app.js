var express = require('express');
const bodyparser=require('body-parser')
const app = express();
app.use(bodyparser.urlencoded({extended:true}));
var path = require('path');

var emprouter = require('./src/routes/employeesrouter.js');

app.set("view engine","ejs");
app.set("views","./src/views");

// app.use(express.static(path.join(__dirname,"public")));
app.use('/employees',emprouter);

app.get('/',(req,res)=>{
    res.render("index");
})

app.listen(8081,()=>{
    console.log("Listening to 8081")
})