const express = require('express');
const authorRouter = express.Router();
var authors = [
    {
        name: "apj abdul kalam",
        age: "75",
        place: "Ramesharam",
        image: "/img/img1.jpeg"
    },
    {
        name: "kamalasuraya",
        age: "60",
        place: "kozhikode",
        image: "/img/img2.jpg"
    },
    {
        name: "onv kurip",
        age: "72",
        place: "alapuzha",
        image: "/img/img3.jpg",
    },
]

function router(nav) {
    authorRouter.route('/')
        .get((req, res) => {
            res.render('authors.ejs',
                {
                    nav,authors,
                    title: "Author"
                });

        });
        authorRouter.route('/addauthor').get((req,res)=>{
            res.render('addauthor.ejs',{    
                nav,
                title:"Addauthor",
                authors
            
        });
        });
        authorRouter.route('/save').post((req,res)=>{
        console.log(req.body);
            res.send('author added');
        });
        authorRouter.route('/:id')
        .get((req,res) => {
            var i =req.params.id;
            res.render('authors.ejs',
            {
                nav,
                title:"author",
                authors:authors[i]
            });
        });
    return authorRouter;
}
module.exports = router;